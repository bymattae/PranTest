const { chromium } = require('playwright');
const delay = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();

  await context.addCookies([
    {
      name: 'whop-core.access-token',
      value: 'eyJraWQiOiJkZWZhdWx0LWtleS1pZC1lczI1Ni1wcm9kIiwiYWxnIjoiRVMyNTYifQ.eyJleHAiOjE3NTAyNzAxNjAsInN1YiI6InVzZXJfNHNYdzZ6anZWYWlpTSIsImlhdCI6MTc1MDI2NjU2MCwiaXNzIjoid2hvcC1yYWlscy1wcm9kIiwidHlwIjoiYWNjZXNzIiwidiI6MX0.BIdbnqCg2L_dBd4zRDfPny2hd3KHiskRoqX4_L_TiURYVZzIS3RCnvJEzCQKON8P0hBK1lI2Zi0etpXSfxHBvA',
      domain: 'whop.com',
      path: '/',
      httpOnly: true,
      secure: true,
      sameSite: 'Lax'
    }
  ]);

  const page = await context.newPage();
  await page.goto('https://whop.com/chartpapi/');
  console.log("✅ Logged in and viewing ChartPapi");

  const endTime = Date.now() + 60 * 60 * 1000;

  while (Date.now() < endTime) {
    await page.mouse.move(300 + Math.random() * 100, 300 + Math.random() * 100);
    console.log("⌛ Staying active...");
    await delay(30000);
  }

  console.log("✅ 1 hour complete");
  await browser.close();
})();
